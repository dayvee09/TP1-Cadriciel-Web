
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container">
        <div class="row">
            <div class="col-12 pt-2">
                <div class="row">
                    <div class="col-8">
                        <h1 class="display-one">Liste des étudiants du collège de maisonneuve</h1>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <a href="<?php echo e(route('maisonneuve.create')); ?>" class="btn btn-primary btn-sm mt-5">Ajouter un étudiant</a>
                        </div>
                    </div>
                </div>
                <div class="row">

                    <?php $postCount = 1 ?>
                    <?php $imgCount = 1 ?>

                    <!-- Contrairement au forelse, le foreach ne donne pas la possibilité d'envoyer un message s'il n'y a pas de correspondance -->
                    <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <!-- 2e paramètre est le post id pour nous amener à l'article en question. Pratique quand on change de serveur et que les routes changent -->
                    <?php if($postCount == 1): ?>
                    <div class="row mt-5">
                        <?php endif; ?>
                        <div class="col-lg-4 mt-3">
                            <div class="text-center card-box">
                                <div class="member-card pt-2 pb-2">
                                    <div class="thumb-lg member-thumb mx-auto">
                                        <?php if($imgCount == 11): ?>
                                        <?php $imgCount = 1 ?>
                                        <?php endif; ?>
                                        <img src=<?php echo e(asset('img/' . $imgCount . '.jpg')); ?> class="img-thumbnail" alt="user-profil">
                                    </div>
                                    <div>
                                        <button class="btn btn-primary mt-3 btn-rounded waves-effect w-md waves-light">
                                            <a class="text-white" href="<?php echo e(route('maisonneuve.show', $post->id)); ?>"><?php echo e(ucfirst($post->nom)); ?></a>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php $postCount++ ?>
                        <?php if($postCount == 4): ?>
                    </div>
                    <?php $postCount == 1 ?>
                    <?php endif; ?>
                    <?php $imgCount++ ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="text-warning">Aucun étudiant disponible</div>
                    <?php endif; ?>
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Cadriciel-Web\Projets\Maisonneuve2195277\Maisonneuve2195277\resources\views/maisonneuve/index.blade.php ENDPATH**/ ?>