
<!-- <?php $__env->startSection('title', 'titre personnalisé'); ?> -->
<?php $__env->startSection('content'); ?>
<div class="container">
    <?php $imgCount = $imgCount % 10 ?>
    <div class="row">
        <div class="col-12 pt-2">
            <a href="<?php echo e(route('maisonneuve')); ?>" class="btn btn-primary btn-sm">Retourner</a>
            <hr>
            <h1 class="display-one"><?php echo e(ucfirst($etudiant->nom)); ?></h1>
            <img src=<?php echo e(asset('img/' . $imgCount . '.jpg')); ?> class="img-thumbnail" alt="user-profil">
            <hr>
            <p><strong>Adresse:</strong> <?php echo $etudiant->adresse; ?></p>
            <p><strong>Email:</strong> <?php echo $etudiant->email; ?></p>
            <p><strong>Date de naissance: </strong><?php echo $etudiant->ddn; ?></p>
            <p><strong>Numéro de téléphone: </strong><?php echo $etudiant->phone; ?></p>
            <p><strong>Ville:</strong> <?php echo $ville->nom; ?></p>
            <hr>
            <a href="<?php echo e(route('maisonneuve.edit', $etudiant->id)); ?>" class="btn btn-outline-primary">Modifier l'étudiant</a>
            <hr>
            <form method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="btn btn-outline-danger">Supprimer</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Cadriciel-Web\Projets\Maisonneuve2195277\Maisonneuve2195277\resources\views/maisonneuve/show.blade.php ENDPATH**/ ?>