
<?php $__env->startSection('content'); ?>


<div class="container">
    <div class="row">
        <div class="col-12 pt-2">
            <h1 class="display-4">Créer un nouvel étudiant</h1>
            <div class="card mt-5">
                <div class="card-header">Nouvel étudiant</div>
                <div class="card-body">
                    <form method="post">
                        <?php echo csrf_field(); ?>
                        <div clas="row">
                            <div class="control-group">
                                <label for="nom">Nom</label>
                                <input type="text" name="nom" id="nom" class="form-control mt-2">
                            </div>
                            <div class="control-group">
                                <label for="adresse">Adresse</label>
                                <input type="text" name="adresse" id="adresse" class="form-control mt-2">
                            </div>
                            <div class="control-group">
                                <label for="phone">Numéro de téléphone</label>
                                <input type="text" name="phone" id="phone" class="form-control mt-2">
                            </div>
                            <div class="control-group">
                                <label for="email">Email</label>
                                <input type="text" name="email" id="email" class="form-control mt-2">
                            </div>
                            <div class="control-group">
                                <label for="ddn">Date de naissance</label>
                                <input type="text" name="ddn" id="ddn" class="form-control mt-2">
                            </div>
                            <div class="control-group">
                                <label for="ville_id">Ville</label>
                                <select name="ville_id" id="ville_id" class="form-control mt-2">
                                    <?php $__currentLoopData = $villes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ville): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($ville->id); ?>"><?php echo e($ville->nom); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="control-group">
                                <input type="submit" class="btn btn-success mt-2" value="Envoyer">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Cadriciel-Web\Projets\Maisonneuve2195277\Maisonneuve2195277\resources\views/maisonneuve/create.blade.php ENDPATH**/ ?>