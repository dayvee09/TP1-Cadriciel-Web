-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : lun. 04 juil. 2022 à 23:55
-- Version du serveur :  10.4.19-MariaDB
-- Version de PHP : 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `maisonneuve2195277`
--

-- --------------------------------------------------------

--
-- Structure de la table `maisonneuves`
--

CREATE TABLE `maisonneuves` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nom` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adresse` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ddn` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `ville_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `maisonneuves`
--

INSERT INTO `maisonneuves` (`id`, `nom`, `adresse`, `phone`, `email`, `ddn`, `created_at`, `updated_at`, `ville_id`) VALUES
(1, 'Elisa Wilderman', '166 Wilkinson Lodge\nPort Amirview, PA 91701', '678-971-7219', 'lindgren.leora@example.org', '1956-06-21 20:15:29', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 9),
(2, 'Jasmin Sanford', '144 Cremin Circles Suite 782\nNeldastad, IA 31281', '1-831-763-4586', 'pfeffer.charley@example.com', '2001-01-25 11:39:10', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 4),
(3, 'Kylee Terry', '9270 Donavon Point Suite 113\nWest Marcos, DC 88584', '+15519642099', 'rae.west@example.com', '1967-07-03 11:26:55', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 15),
(4, 'Korey Lemke', '1945 Quincy Estate Apt. 670\nSouth Erna, CA 56583-0178', '253.639.8489', 'dibbert.sven@example.org', '2000-02-10 16:35:14', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 8),
(5, 'Prof. Bria Dietrich', '7929 Rau Turnpike\nEast Cecelia, AZ 60828-0297', '614.892.6012', 'floy90@example.org', '1988-04-24 02:28:32', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 6),
(6, 'Gladys Macejkovic', '740 Stan Track\nLangworthstad, WV 34988-1635', '+1-360-969-3549', 'harmon33@example.org', '1954-04-11 18:43:10', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 6),
(7, 'Timothy Ratke', '61141 Noelia Shoal\nPort Hayleefort, WY 98073-3681', '832-727-0235', 'abshire.melyna@example.org', '1992-09-13 01:22:28', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 12),
(8, 'Dr. Hilma Doyle Sr.', '244 Prohaska Pass\nSouth Bartonbury, PA 50111', '+1-843-285-4931', 'linnea98@example.org', '2000-05-21 11:36:40', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 7),
(9, 'Marie Cummerata', '3056 Joshuah Skyway Suite 693\nWiegandton, WA 50337', '1-218-866-5453', 'gerard.jast@example.org', '1973-02-06 19:55:20', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 5),
(10, 'Chaim Cummings DDS', '8146 Daisy Bypass\nNorth Dandrestad, OK 91370-0864', '1-260-658-5756', 'howell.celine@example.com', '1985-10-22 11:53:05', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 13),
(11, 'Gerson Marquardt', '4096 Rosendo Pines Suite 908\nJacobstown, AR 79345', '+1-828-816-2395', 'smitham.tracey@example.net', '1984-02-08 03:12:14', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 2),
(12, 'Zoie Schoen', '38559 Talon Mountains\nBaumbachfort, LA 04648-2955', '+1 (501) 791-8312', 'sboehm@example.net', '1991-11-23 06:41:12', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 10),
(13, 'Prof. Jeramie Murray', '3050 Torp Mill Apt. 282\nEast Jody, IL 01678', '(423) 865-0569', 'ledner.myriam@example.net', '1971-10-30 21:57:47', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 8),
(14, 'Prof. Stewart Prohaska Sr.', '4034 Natalie Mountains Apt. 189\nEast Rosa, LA 76789', '443-721-3528', 'glennie.weber@example.net', '1995-02-05 16:42:11', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 15),
(15, 'Mr. Carmine Baumbach IV', '805 Hahn Knoll\nNorth Khalidton, CO 48252-5460', '571.640.3897', 'klocko.delpha@example.com', '1980-06-04 18:08:04', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 6),
(16, 'Esperanza Daniel', '630 Ruth Trafficway Apt. 483\nSouth Adelatown, OK 03926-1818', '+1-223-316-1039', 'mose89@example.net', '1963-01-28 06:24:58', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 10),
(17, 'Freda Auer', '956 Mertz Freeway\nLake Dexter, NV 73135-2062', '936.634.9493', 'rcummings@example.com', '1972-06-02 18:08:55', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 1),
(18, 'Daphne Hudson', '1867 Keebler Lights Apt. 478\nEast Robbtown, NC 68721-1934', '+1-571-314-1755', 'lessie97@example.com', '1977-11-25 09:17:45', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 8),
(19, 'Elijah Brekke IV', '56830 Ibrahim Heights\nJuliafurt, FL 00928-3413', '(681) 649-5877', 'anastasia.treutel@example.com', '2000-02-17 18:36:31', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 13),
(20, 'Eliane Beer', '887 Olson Harbor\nWest Kayceeside, GA 75001', '+1.580.916.8013', 'glenna81@example.com', '1967-09-28 20:02:28', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 2),
(21, 'Mr. Bernard Mayert I', '263 Hoppe Cove Suite 156\nHudsonburgh, OH 67637-5754', '1-551-212-0645', 'francisca.gislason@example.com', '1979-04-17 23:02:30', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 13),
(22, 'Roger Goyette', '825 Brennan Spring\nLake Destin, MI 56133-6994', '(934) 702-2259', 'eichmann.may@example.org', '1968-08-08 09:19:35', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 10),
(23, 'Jevon Stark', '1870 Sipes Meadow Apt. 329\nSouth Erica, AZ 48852', '+1.640.354.3401', 'rkozey@example.net', '1985-12-27 14:15:50', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 7),
(24, 'Mohammed Little PhD', '83357 Katrina Forges\nToyton, NE 53434-6847', '1-331-689-1521', 'brain30@example.com', '1963-04-05 01:32:35', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 13),
(25, 'Prof. Soledad Crooks MD', '8223 Legros Underpass Apt. 886\nKreigerburgh, GA 72655', '+1-240-931-6686', 'hailie88@example.net', '1990-01-06 09:58:05', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 2),
(26, 'Ms. Adela Weimann V', '5495 Ernser Keys\nKeonview, SC 94145-1104', '+1 (559) 516-9787', 'fnitzsche@example.org', '1980-12-06 21:44:59', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 2),
(27, 'Prof. Kailey Kreiger', '583 Murphy Mall Suite 753\nHammesview, NY 65399', '+12532272219', 'rollin42@example.org', '1959-12-13 09:49:12', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 9),
(28, 'Alfredo Haley', '285 Zita Plaza\nWest Jadyn, VT 93414-1682', '1-361-383-3594', 'swalsh@example.org', '1960-05-23 20:12:42', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 2),
(29, 'Derek Bruen Jr.', '439 McClure Lodge\nThaddeusshire, NJ 74032-9245', '+1.863.612.8746', 'cathrine.stanton@example.net', '1953-05-10 10:45:03', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 14),
(30, 'Dr. Winfield Goldner', '691 Beahan Pike\nBartonfort, WY 10471', '925.240.4460', 'aleen.mertz@example.org', '1991-06-15 01:49:03', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 5),
(31, 'Dr. Jaycee Tromp Sr.', '904 Haskell Cliff\nNew Monte, SC 54656', '364.820.1478', 'clair.klocko@example.com', '1954-10-19 00:18:24', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 8),
(32, 'Ms. Lois Kirlin I', '25606 Veum Highway Apt. 729\nHaroldport, AK 68523', '+1.470.324.6339', 'abbott.darby@example.org', '1974-08-11 20:40:13', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 7),
(33, 'Jayson Stark', '904 Medhurst Harbors Apt. 184\nEast Diego, IA 77951', '478-833-5802', 'antonetta51@example.com', '2000-07-09 08:51:47', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 14),
(34, 'Jalyn Abshire', '8809 Terry Divide Suite 080\nWest Brendan, ND 12196', '+1.618.588.6605', 'aglae.dooley@example.com', '1964-03-25 08:57:45', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 3),
(35, 'Mr. Everardo Mueller', '703 Ashley Meadows\nSouth Adrien, WA 28973', '1-919-860-9574', 'janiya48@example.net', '1959-05-31 01:29:40', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 10),
(36, 'Edna Wehner', '3975 Weimann Divide Suite 979\nOberbrunnermouth, MI 75971', '1-520-281-6388', 'boyer.nathaniel@example.com', '1968-07-17 05:17:04', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 7),
(37, 'Miss Alessandra McClure III', '19933 Hayes Ways\nBartolettiton, OK 50063-3379', '435.401.5086', 'farrell.kamille@example.org', '1997-10-03 17:08:31', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 12),
(38, 'Beau Witting II', '54406 Denesik Hill\nNew Vida, AZ 33077', '+1.283.404.9946', 'diana.ward@example.com', '2001-07-08 21:38:00', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 13),
(39, 'Eva Rice', '595 McDermott Via Apt. 551\nSouth Kylechester, CT 41688-7018', '408-767-5372', 'lhomenick@example.org', '1994-05-09 15:39:13', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 5),
(40, 'Mr. Joesph Jerde', '716 Waters Curve\nJarenmouth, OK 69205-1941', '+16519636110', 'christopher92@example.org', '1977-07-14 05:01:16', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 6),
(41, 'Prof. Natasha Bogisich Sr.', '1593 Johnson Unions Suite 582\nLessiestad, DC 00593-7368', '(423) 889-0930', 'stacey22@example.com', '1982-04-26 06:58:12', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 11),
(42, 'Vivien DuBuque', '62136 Crooks Garden\nEast Simoneview, AZ 15610-2130', '+1 (229) 435-3773', 'owolff@example.org', '1989-03-21 20:25:45', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 3),
(43, 'Mr. Lukas Schmitt PhD', '2596 Dedric Center Apt. 943\nNew Herminia, ND 50021-1900', '352.444.3721', 'gaylord.sylvan@example.com', '1963-05-16 20:23:30', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 3),
(44, 'Dr. Zachary Hodkiewicz', '941 Borer Drive\nSouth Danielle, NC 84325-1804', '910.419.0840', 'roberta09@example.net', '1952-08-30 21:51:22', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 5),
(45, 'Kaylin Kling I', '460 Elinore Square Apt. 643\nNew Madonnachester, CT 77967-6153', '+1-938-561-4816', 'osborne.gibson@example.net', '1965-02-16 11:34:20', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 9),
(46, 'Prof. Jeromy Batz MD', '998 Hane Tunnel Apt. 582\nEast Madyson, MS 98989-7396', '614.981.9518', 'rbeahan@example.net', '1976-12-31 17:30:51', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 11),
(47, 'Dr. Matt Gibson MD', '19471 Eichmann Station\nHesselstad, SD 05244-9940', '+1 (423) 234-7882', 'huel.joany@example.com', '1953-02-27 13:19:27', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 13),
(48, 'Prof. Daphne Friesen Jr.', '410 Leannon Wall Apt. 687\nOthoville, RI 42748', '+1-620-490-2079', 'vsporer@example.net', '1981-10-23 04:13:28', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 3),
(49, 'Idella Pfeffer', '906 Haag Mountains Suite 305\nEfrainfurt, LA 72064', '+1 (279) 471-1854', 'thalia.waelchi@example.com', '1955-02-12 20:32:51', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 15),
(50, 'Beth Gibson V', '5462 Casper Passage Suite 785\nCullenville, WA 56289-4156', '956.549.9087', 'arenner@example.com', '1997-10-30 23:35:36', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 13),
(51, 'Prof. Jovani Collier MD', '5222 Pagac Ferry\nMurphyton, MS 78773-7904', '+1-920-701-3179', 'tbotsford@example.com', '1999-12-04 17:00:39', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 13),
(52, 'Kira Jakubowski', '12803 Letha Vista\nNorth Christophe, HI 09639-8272', '754.334.0684', 'adolfo.senger@example.org', '1964-02-26 19:07:10', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 3),
(53, 'Vita Hand', '4273 King Ford Apt. 289\nBlairchester, NY 26835', '+1-347-263-8572', 'mmitchell@example.com', '1961-03-25 19:38:57', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 6),
(54, 'Erica Koss', '2537 Gaylord Village Suite 691\nHillfurt, HI 56012-8867', '(559) 912-4318', 'jalyn12@example.org', '1973-10-09 20:08:21', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 7),
(55, 'Rey Hagenes', '2865 Anastasia Track\nNorth Oma, OR 33725-4648', '+1.336.593.2726', 'cleta11@example.com', '1988-03-05 03:53:25', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 4),
(56, 'Veda Dibbert', '8380 Stokes Burgs\nWebsterfort, AR 25795-3575', '(814) 725-2040', 'carlo.hahn@example.com', '1965-06-07 20:06:57', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 10),
(57, 'Dr. Lavina McKenzie II', '3748 Celia Fort Suite 503\nMorissettefort, IA 11554-8068', '551.533.0496', 'kacie.leuschke@example.com', '1955-12-03 12:34:10', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 2),
(58, 'Josefa Schaden', '705 Sonia Plaza Apt. 319\nPort Marshallbury, GA 99565', '1-458-896-9946', 'turner.granville@example.org', '1966-02-25 20:59:40', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 9),
(59, 'Simeon Lueilwitz', '16761 Jamie Orchard Apt. 355\nNew Dinaton, KY 82886-9106', '862-755-2771', 'marks.carmel@example.com', '1992-04-18 18:42:47', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 3),
(60, 'Carley Williamson', '730 Stella Drives\nLazaroshire, OR 55094', '850.865.0931', 'henri.kautzer@example.com', '1955-09-04 20:08:47', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 2),
(61, 'Issac Kuvalis', '28161 Emard Springs\nEast Jaquelinmouth, NE 20744-8977', '1-856-402-0668', 'marge07@example.net', '1990-12-28 13:53:37', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 2),
(62, 'Margarete Hill', '529 Crooks Spur\nPort Camilaborough, MO 13124', '+1-774-515-2341', 'werdman@example.org', '1967-03-18 21:59:12', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 12),
(63, 'Mohammed Rath', '8867 Amya Isle Suite 194\nNew Dawsonton, VT 29524', '+14309364658', 'rjohnston@example.net', '1982-07-17 05:10:36', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 10),
(64, 'Leanna Braun', '7066 Sporer Fork\nEast Sanfordmouth, DE 84781', '973-677-0730', 'vsenger@example.com', '1994-02-19 04:27:27', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 5),
(65, 'Ayla Gutkowski', '1537 Satterfield Vista Apt. 152\nNew Violettown, MD 94802', '620.524.4038', 'jack.carroll@example.org', '1984-01-23 21:11:51', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 5),
(66, 'Dr. Ruben Parker DDS', '6033 Krajcik Trail Apt. 672\nEast Isabelleburgh, TN 67174', '1-661-657-0084', 'peter.hettinger@example.org', '1975-06-03 01:02:24', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 3),
(67, 'Dr. Martin Smith', '4200 Raynor Parkway\nLake Kianna, NC 19397-7230', '1-626-244-6290', 'randall.jaskolski@example.net', '1987-11-24 18:46:34', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 1),
(68, 'Arnoldo Zboncak', '347 Rutherford Extensions\nWesttown, WA 28998', '+1 (225) 601-2909', 'bharris@example.org', '1973-04-26 12:12:12', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 11),
(69, 'Alysa Windler', '78211 Margie Mountain\nJoanniechester, SC 06992-3761', '(207) 969-2128', 'schiller.gracie@example.net', '1964-05-04 22:51:51', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 5),
(70, 'Bill Kunde III', '7034 Solon Wall\nSouth Maida, DE 30495-4136', '(940) 846-7018', 'vella19@example.net', '1954-07-11 23:55:02', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 1),
(71, 'Ms. Lizeth Thiel', '86175 Markus Prairie Apt. 513\nBradtkefort, MA 36101-0178', '(475) 368-9398', 'damion.pfannerstill@example.org', '1955-04-05 06:10:42', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 7),
(72, 'Micheal Reilly MD', '64698 O\'Keefe Gateway\nPort Doloresmouth, OK 46764-3080', '(760) 835-7081', 'huels.tre@example.com', '1987-11-24 10:19:44', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 10),
(73, 'Prof. Zelda Keebler', '28154 Cortez Motorway\nNew Kevinchester, VA 46697-9403', '1-757-967-9653', 'zabbott@example.com', '1995-04-22 15:50:02', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 12),
(74, 'Mr. Hillard Kihn', '4356 Bins Plain Suite 525\nSouth Trystan, IA 67825-8118', '215.255.6340', 'pcronin@example.net', '1952-10-02 00:19:33', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 8),
(75, 'Prof. Precious Carroll', '274 Schaefer Rapids Apt. 317\nSouth Doloresstad, CO 51119', '+1-732-752-0667', 'kris.amaya@example.com', '1990-11-19 08:31:49', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 13),
(76, 'Prof. Conner Lang II', '171 Teresa Pines Suite 520\nKeaganland, OH 30635-3596', '1-860-285-0111', 'larson.alanna@example.org', '1979-01-03 04:52:01', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 10),
(77, 'Germaine Grimes IV', '238 Shaniya Road Suite 641\nSouth Jacey, GA 18658-8335', '1-985-593-8359', 'jolie05@example.com', '1954-04-27 06:39:49', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 4),
(78, 'Joel Stark', '525 Carlos Forks Apt. 758\nSouth Lexus, MS 12292-1786', '+1-385-767-1262', 'mitchell.dallas@example.net', '1973-07-25 07:42:05', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 5),
(79, 'Zaria Runolfsdottir Sr.', '9115 Savion Mill Apt. 834\nFunkview, GA 16485', '+1 (432) 356-5303', 'daisha86@example.net', '1961-06-11 04:26:21', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 8),
(80, 'Dayana Upton', '61471 Wilderman Haven\nNew Dino, UT 44061-4968', '718-663-0480', 'olson.rylan@example.net', '1972-05-10 23:15:38', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 13),
(81, 'Janiya Streich', '21060 VonRueden Circles Suite 609\nSouth Sunny, WA 70216', '+13302846602', 'cpollich@example.org', '1971-07-22 04:18:00', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 5),
(82, 'Loyal Parisian', '53091 Kamille Overpass\nNorth Nicklausshire, SC 71522', '+1-272-446-6620', 'dawson58@example.net', '1986-12-08 15:19:54', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 11),
(83, 'Osvaldo Tillman', '32221 Mae Knolls Suite 824\nBergebury, OK 87480-8203', '(607) 823-1334', 'cassin.donna@example.com', '1976-02-15 20:40:20', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 3),
(84, 'Dr. Ransom Abernathy', '6308 Aufderhar Drives Apt. 456\nNew Walton, LA 38259-3871', '(318) 839-9124', 'eulah82@example.org', '1976-10-18 21:22:55', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 14),
(85, 'Ms. Maribel Swift IV', '3172 Bode Rapids Apt. 188\nPort Rosellaborough, ND 99848-1543', '689-532-5806', 'ebergnaum@example.net', '1988-03-20 21:18:39', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 7),
(86, 'Coby Bode', '545 Gorczany Haven\nEast Jarred, ID 09409-8963', '1-850-420-5782', 'satterfield.nicholaus@example.net', '1971-02-11 11:54:29', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 3),
(87, 'Orlo Willms', '5577 Haag Mall\nAndersonville, OK 41386', '(480) 304-1614', 'xtrantow@example.com', '1998-07-04 02:47:07', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 15),
(88, 'Brandt Mann', '7365 Christy Springs\nCristianchester, AL 08344', '1-984-421-0654', 'rtillman@example.org', '1981-12-30 21:39:40', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 6),
(89, 'Daren Yost', '195 Colt View Apt. 288\nWest Jevon, AL 01585-1156', '1-954-907-6599', 'ucollins@example.net', '1992-12-13 21:00:35', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 8),
(90, 'Leatha Torphy', '693 Therese Ferry Suite 001\nWest Mandy, MN 84832', '+1 (530) 530-2500', 'zmarquardt@example.org', '1965-08-14 04:26:53', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 8),
(91, 'Chelsie Olson', '16593 Effertz Gateway\nGerholdshire, ND 13131', '+1 (469) 394-0238', 'ivy12@example.org', '1951-10-20 10:45:45', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 15),
(92, 'Prof. Osbaldo Cole IV', '6436 Rolfson Course Suite 266\nNameburgh, LA 82575-5213', '754.682.1845', 'becker.janessa@example.net', '2003-01-01 03:55:23', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 12),
(93, 'Kylee Lang', '36973 Norbert Camp Suite 454\nLake Cierraberg, HI 93440', '+1-337-484-4104', 'trycia37@example.org', '1973-02-06 18:38:53', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 14),
(94, 'Francesco Nolan', '279 Kaden Tunnel Suite 724\nEast Kenyonchester, LA 80158', '(773) 837-9086', 'lconsidine@example.com', '1982-02-01 23:58:39', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 10),
(95, 'Julien Keebler', '14082 Ava Groves Suite 313\nSouth Fredaside, AZ 30676', '(423) 841-5697', 'margarett.schowalter@example.org', '1971-12-18 19:00:32', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 5),
(96, 'Dr. Adriel O\'Kon', '616 Streich View\nHarrymouth, KY 52916-5449', '254.628.0183', 'alene.dubuque@example.net', '1989-06-24 13:01:04', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 8),
(97, 'Mr. Otis Thompson', '357 Doyle Light Apt. 549\nMurraystad, MT 39784-0647', '763-885-2660', 'edd.brown@example.net', '1988-08-06 21:32:25', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 13),
(98, 'Terrance Collins', '241 Dedrick Mountain\nWeststad, MA 50069-2516', '740-647-8121', 'hill.pascale@example.net', '1993-03-15 16:43:37', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 11),
(99, 'Theodora Wunsch', '863 Grant Crossroad\nNew Jaylin, PA 09832-0889', '+1-346-550-0410', 'mueller.christy@example.net', '1968-03-17 09:15:30', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 1),
(100, 'Christina Ledner', '87587 Donnell Way Suite 588\nLake Bernhard, MO 27048', '857-295-6985', 'caitlyn06@example.org', '1986-03-13 04:54:17', '2022-06-24 19:59:18', '2022-06-24 19:59:18', 11),
(101, 'David Deschênes', '3029 blvd. Édouard Montpetit', '514-601-8075', 'davids09@hotmail.com', '1987-02-01', '2022-06-24 21:00:14', '2022-07-04 17:51:21', 1),
(104, 'Robert DeNiro', '3050, Lombart Street, San Francisco', '18325543', 'deNiro@robert.com', '1943-10-17', '2022-07-05 01:32:10', '2022-07-05 01:32:10', 11);

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(2, '2022_06_24_132853_create_villes_table', 1),
(3, '2022_06_24_133007_create_maisonneuves_table', 1);

-- --------------------------------------------------------

--
-- Structure de la table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `villes`
--

CREATE TABLE `villes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `villes`
--

INSERT INTO `villes` (`id`, `nom`, `created_at`, `updated_at`) VALUES
(1, 'Boganberg', '2022-06-24 19:46:52', '2022-06-24 19:46:52'),
(2, 'New Lesterbury', '2022-06-24 19:46:52', '2022-06-24 19:46:52'),
(3, 'Raoulville', '2022-06-24 19:46:52', '2022-06-24 19:46:52'),
(4, 'Lake Ike', '2022-06-24 19:46:52', '2022-06-24 19:46:52'),
(5, 'North Ettie', '2022-06-24 19:46:52', '2022-06-24 19:46:52'),
(6, 'New Moriah', '2022-06-24 19:46:52', '2022-06-24 19:46:52'),
(7, 'West Cecelialand', '2022-06-24 19:46:52', '2022-06-24 19:46:52'),
(8, 'East Biankafurt', '2022-06-24 19:46:52', '2022-06-24 19:46:52'),
(9, 'Kubport', '2022-06-24 19:46:52', '2022-06-24 19:46:52'),
(10, 'Gillianview', '2022-06-24 19:46:52', '2022-06-24 19:46:52'),
(11, 'Ivorybury', '2022-06-24 19:46:52', '2022-06-24 19:46:52'),
(12, 'Rauside', '2022-06-24 19:46:52', '2022-06-24 19:46:52'),
(13, 'New Rogelio', '2022-06-24 19:46:52', '2022-06-24 19:46:52'),
(14, 'Bradleymouth', '2022-06-24 19:46:52', '2022-06-24 19:46:52'),
(15, 'Kassulkechester', '2022-06-24 19:46:52', '2022-06-24 19:46:52');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `maisonneuves`
--
ALTER TABLE `maisonneuves`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `maisonneuves_email_unique` (`email`),
  ADD KEY `maisonneuves_ville_id_foreign` (`ville_id`);

--
-- Index pour la table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Index pour la table `villes`
--
ALTER TABLE `villes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `maisonneuves`
--
ALTER TABLE `maisonneuves`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;

--
-- AUTO_INCREMENT pour la table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `villes`
--
ALTER TABLE `villes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `maisonneuves`
--
ALTER TABLE `maisonneuves`
  ADD CONSTRAINT `maisonneuves_ville_id_foreign` FOREIGN KEY (`ville_id`) REFERENCES `villes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
